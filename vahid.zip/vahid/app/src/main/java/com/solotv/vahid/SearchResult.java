package com.solotv.vahid;


public class SearchResult {


    String title;

    String imageUrl;

    String type;


    Genre genre;

    Movie movie;



    public SearchResult(Genre genre){


        this.genre = genre;


        this.title = genre.getName();


        this.imageUrl = genre.getImageUrl();


        this.type = "genre";


    }




    public SearchResult(Movie movie){


        this.movie = movie;


        this.title = movie.getTitle();


        this.imageUrl = movie.getImageUrl();


        this.type = "movie";


    }




    public String getTitle(){


        return title;


    }





    public String getImageUrl(){


        return imageUrl;


    }





    public String getType(){


        return type;


    }





    public Genre getGenre(){


        return genre;


    }





    public Movie getMovie(){


        return movie;


    }


}
