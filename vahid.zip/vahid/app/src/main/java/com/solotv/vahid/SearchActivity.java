package com.solotv.vahid;


import android.app.Activity;
import android.os.Bundle;

import android.graphics.Color;

import android.view.View;

import android.webkit.WebView;
import android.webkit.WebSettings;

import android.text.Editable;
import android.text.TextWatcher;

import android.widget.EditText;
import android.widget.GridView;
import android.widget.TextView;


import java.util.ArrayList;



public class SearchActivity extends Activity {



    EditText searchInput;

    GridView resultGrid;

    TextView emptyText;


    WebView searchBackground;



    ArrayList<SearchResult> results;


    SearchAdapter adapter;





    @Override
    protected void onCreate(Bundle savedInstanceState){


        super.onCreate(savedInstanceState);


        setContentView(R.layout.search);




        // اتصال بک گراند 2

        searchBackground = findViewById(R.id.searchBackground);



        WebSettings settings = searchBackground.getSettings();


        settings.setJavaScriptEnabled(true);


        settings.setDomStorageEnabled(true);



        searchBackground.setBackgroundColor(

			Color.TRANSPARENT

        );



        searchBackground.setLayerType(

			View.LAYER_TYPE_HARDWARE,

			null

        );



        searchBackground.loadUrl(

			"file:///android_asset/background2.html"

        );







        searchInput = findViewById(R.id.searchInput);

        resultGrid = findViewById(R.id.resultGrid);

        emptyText = findViewById(R.id.emptyText);





        results = new ArrayList<>();



        adapter = new SearchAdapter(

			this,

			results

        );



        resultGrid.setAdapter(adapter);





        searchInput.addTextChangedListener(

			new TextWatcher(){



				@Override
				public void beforeTextChanged(
					CharSequence s,
					int start,
					int count,
					int after
				){

				}





				@Override
				public void onTextChanged(
					CharSequence s,
					int start,
					int before,
					int count
				){


					doSearch(s.toString());


				}





				@Override
				public void afterTextChanged(
					Editable e
				){

				}



			}


        );



    }








    void doSearch(String text){


        results.clear();



        text = text.trim().toLowerCase();




        if(text.length()==0){


            adapter.notifyDataSetChanged();


            emptyText.setText("");


            return;


        }





        if(GenreCache.genreList != null){


            for(Genre g : GenreCache.genreList){



                if(g.getName()

				   .toLowerCase()

				   .contains(text)){



                    results.add(

						new SearchResult(g)

                    );


                }


            }


        }







        if(MovieCache.movieList != null){


            for(Movie m : MovieCache.movieList){



                if(m.getTitle()

				   .toLowerCase()

				   .contains(text)){



                    results.add(

						new SearchResult(m)

                    );


                }


            }


        }






        adapter.notifyDataSetChanged();





        if(results.size()==0){


            emptyText.setText(

				"نتیجه‌ای پیدا نشد"

            );


        }

        else{


            emptyText.setText("");


        }



    }



}
