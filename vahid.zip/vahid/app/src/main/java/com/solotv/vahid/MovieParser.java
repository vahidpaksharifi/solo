package com.solotv.vahid;


import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;



public class MovieParser {


    public static ArrayList<Movie> parse(String json){


        ArrayList<Movie> list = new ArrayList<>();


        try{


            JSONArray array = new JSONArray(json);



            for(int i = 0; i < array.length(); i++){



                JSONObject obj = array.getJSONObject(i);



                String title =
					obj.getString("title");


                String imageUrl =
					obj.getString("imageUrl");


                String videoUrl =
					obj.getString("videoUrl");



                list.add(

					new Movie(

						title,

						imageUrl,

						videoUrl

					)

                );

            }



        }catch(Exception e){


            e.printStackTrace();


        }



        return list;


    }


}
