package com.solotv.vahid;


import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;



public class GenreParser {



    public static ArrayList<Genre> parse(String json) {



        ArrayList<Genre> list = new ArrayList<>();



        try {



            JSONArray array = new JSONArray(json);



            for(int i = 0; i < array.length(); i++){



                JSONObject object = array.getJSONObject(i);



                String name =
                    object.getString("name");



                String imageUrl =
                    object.getString("imageUrl");



                String moviesUrl =
                    object.getString("moviesUrl");



                list.add(

                    new Genre(

                        name,

                        imageUrl,

                        moviesUrl

                    )

                );



            }



        } catch(Exception e) {



            e.printStackTrace();



        }



        return list;



    }



}
