package com.solotv.vahid;

import java.util.ArrayList;

public class BannerData {


    public static ArrayList<Banner> getBanners() {


        return new ArrayList<>();


    }


}
