package com.solotv.vahid;


import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;


public class GenreAdapter extends BaseAdapter {


    private Context context;

    private ArrayList<Genre> genreList;



    public GenreAdapter(Context context, ArrayList<Genre> genreList) {


        this.context = context;

        this.genreList = genreList;


    }




    @Override
    public int getCount() {


        return genreList.size();


    }




    @Override
    public Object getItem(int position) {


        return genreList.get(position);


    }




    @Override
    public long getItemId(int position) {


        return position;


    }





    @Override
    public View getView(int position, View convertView, ViewGroup parent) {



        if (convertView == null) {


            convertView = LayoutInflater.from(context)

				.inflate(R.layout.movie_item, parent, false);


        }





        ImageView image =

			convertView.findViewById(R.id.moviePoster);





        TextView title =

			convertView.findViewById(R.id.movieTitle);





        final Genre genre =

			genreList.get(position);






        title.setText(genre.getName());





        ImageLoader.load(
			context,
			genre.getImageUrl(),
			image
		);






        convertView.setOnClickListener(new View.OnClickListener() {


				@Override
				public void onClick(View v) {



					Intent intent =

                        new Intent(

						context,

						MovieListActivity.class

					);





					intent.putExtra(

                        "genreId",

                        genre.getId()

					);





					intent.putExtra(

                        "genreName",

                        genre.getName()

					);





					context.startActivity(intent);



				}


			});





        return convertView;


    }



}
