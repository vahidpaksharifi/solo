package com.solotv.vahid;


import java.util.ArrayList;


public class MovieCache {


    public static ArrayList<Movie> movieList =

	new ArrayList<>();


}
