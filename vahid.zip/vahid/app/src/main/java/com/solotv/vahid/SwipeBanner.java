package com.solotv.vahid;


import android.content.Context;
import android.content.Intent;
import android.net.Uri;

import android.graphics.Color;
import android.graphics.Outline;
import android.graphics.drawable.GradientDrawable;

import android.os.Handler;
import android.util.AttributeSet;

import android.view.MotionEvent;
import android.view.View;
import android.view.ViewOutlineProvider;

import android.widget.FrameLayout;
import android.widget.ImageView;

import java.util.ArrayList;



public class SwipeBanner extends FrameLayout {


    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {

        int width = MeasureSpec.getSize(widthMeasureSpec);

        int height = width * 9 / 16;

        int newHeightSpec = MeasureSpec.makeMeasureSpec(
			height,
			MeasureSpec.EXACTLY
        );

        super.onMeasure(widthMeasureSpec, newHeightSpec);

    }



    float downX;
    float deltaX;


    int current = 0;


    ArrayList<Banner> banners = new ArrayList<>();


    ImageView currentImage;
    ImageView nextImage;


    View glassView;


    OnBannerChangeListener listener;


    Handler handler = new Handler();




    Runnable autoSlide = new Runnable() {


        @Override
        public void run() {


            if(banners.size() > 1 && nextImage == null){


                current++;


                if(current >= banners.size())

                    current = 0;



                loadCurrent();



                if(listener != null)

                    listener.onChanged(current);


            }


            handler.postDelayed(this,5000);


        }


    };





    public SwipeBanner(Context context) {

        super(context);

    }



    public SwipeBanner(Context context, AttributeSet attrs) {

        super(context, attrs);

    }







    public void setBanners(ArrayList<Banner> banners){


        if(banners == null || banners.size() == 0)

            return;



        this.banners = banners;


        current = 0;


        loadCurrent();


        startAutoSlide();


    }








    private ImageView createImage(int index){



        ImageView image = new ImageView(getContext());



        image.setLayoutParams(

            new LayoutParams(

                LayoutParams.MATCH_PARENT,

                LayoutParams.MATCH_PARENT

            )

        );



        image.setScaleType(

            ImageView.ScaleType.CENTER_CROP

        );



        if(android.os.Build.VERSION.SDK_INT >= 21){


            image.setOutlineProvider(new ViewOutlineProvider(){


					@Override
					public void getOutline(View view, Outline outline){


						outline.setRoundRect(

							0,
							0,
							view.getWidth(),
							view.getHeight(),
							25

						);


					}


				});


            image.setClipToOutline(true);


        }





        ImageLoader.load(

            getContext(),

            banners.get(index).getImageUrl(),

            image

        );



        return image;


    }








    private void loadCurrent(){



        removeAllViews();



        currentImage = createImage(current);



        currentImage.setAlpha(0f);



        addView(currentImage);



        createGlass();



        currentImage.animate()

            .alpha(1f)

            .setDuration(800)

            .start();



    }







    private void createGlass(){



        glassView = new View(getContext());



        glassView.setLayoutParams(

            new LayoutParams(

                LayoutParams.MATCH_PARENT,

                LayoutParams.MATCH_PARENT

            )

        );


        GradientDrawable glass = new GradientDrawable();



        glass.setColor(Color.TRANSPARENT);



        glass.setStroke(

            2,

            Color.argb(130,255,255,255)

        );



        glass.setCornerRadius(25);



        glassView.setBackground(glass);



        addView(glassView);


    }


    private void startAutoSlide(){


        handler.removeCallbacks(autoSlide);


        handler.postDelayed(autoSlide,5000);


    }






    private void stopAutoSlide(){


        handler.removeCallbacks(autoSlide);


    }








    private void prepareNext(boolean next){



        int index;



        if(next){


            index = current + 1;


            if(index >= banners.size())

                index = 0;



        }else{


            index = current - 1;


            if(index < 0)

                index = banners.size()-1;


        }



        nextImage = createImage(index);



        addView(nextImage);



        nextImage.setTranslationX(

            next ? getWidth() : -getWidth()

        );



    }









    @Override
    public boolean onTouchEvent(MotionEvent event){



        switch(event.getAction()){



            case MotionEvent.ACTION_DOWN:

                stopAutoSlide();

                downX = event.getX();

                return true;




            case MotionEvent.ACTION_MOVE:


                deltaX = event.getX() - downX;



                if(nextImage == null && Math.abs(deltaX) > 20){


                    prepareNext(deltaX < 0);


                }



                if(nextImage != null){



                    currentImage.setTranslationX(deltaX);



                    if(deltaX < 0){


                        nextImage.setTranslationX(

                            getWidth() + deltaX

                        );


                    }else{


                        nextImage.setTranslationX(

                            -getWidth() + deltaX

                        );


                    }



                }


                return true;







            case MotionEvent.ACTION_UP:



                if(nextImage != null && Math.abs(deltaX) > getWidth()/3){



                    if(deltaX < 0){


                        current++;


                        if(current >= banners.size())

                            current = 0;



                    }else{


                        current--;


                        if(current < 0)

                            current = banners.size()-1;



                    }




                    currentImage = nextImage;


                    nextImage = null;



                    removeAllViews();



                    addView(currentImage);



                    createGlass();



                    currentImage.setTranslationX(0);




                    if(listener != null)

                        listener.onChanged(current);



                }else{


                    if(currentImage != null)

                        currentImage.setTranslationX(0);



                    if(nextImage != null){


                        removeView(nextImage);


                        nextImage = null;


                    }


                }






                if(Math.abs(deltaX) < 30 && banners.size() > 0){



                    String link = banners.get(current).getLinkUrl();



                    if(link != null && !link.equals("")){


                        Intent intent = new Intent(

                            Intent.ACTION_VIEW,

                            Uri.parse(link)

                        );


                        getContext().startActivity(intent);


                    }

                }





                deltaX = 0;



                startAutoSlide();



                return true;


        }



        return true;


    }







    public int getCurrent(){


        return current;


    }







    public void setOnBannerChangeListener(OnBannerChangeListener l){


        listener = l;


    }







    public interface OnBannerChangeListener{


        void onChanged(int position);


    }



}
