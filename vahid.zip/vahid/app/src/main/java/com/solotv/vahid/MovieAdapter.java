package com.solotv.vahid;


import android.content.Context;
import android.content.Intent;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;



public class MovieAdapter extends BaseAdapter {


    private Context context;

    private ArrayList<Movie> movieList;



    public MovieAdapter(Context context, ArrayList<Movie> movieList) {

        this.context = context;

        this.movieList = movieList;

    }



    @Override
    public int getCount() {

        return movieList.size();

    }



    @Override
    public Object getItem(int position) {

        return movieList.get(position);

    }



    @Override
    public long getItemId(int position) {

        return position;

    }




    @Override
    public View getView(int position, View convertView, ViewGroup parent) {


        if(convertView == null) {


            convertView = LayoutInflater.from(context)

				.inflate(

				R.layout.movie_item,

				parent,

				false

			);

        }




        // کوچک کردن کل کارت پوستر

        int screenWidth = parent.getWidth();


        if(screenWidth > 0) {


            ViewGroup.LayoutParams params =

				convertView.getLayoutParams();



            params.width =

				(int)(screenWidth * 0.42);



            convertView.setLayoutParams(params);



            convertView.setPadding(

				0,

				10,

				0,

				10

            );


        }




        ImageView poster =

			convertView.findViewById(

			R.id.moviePoster

		);



        TextView title =

			convertView.findViewById(

			R.id.movieTitle

		);





        final Movie movie = movieList.get(position);



        title.setText(

			movie.getTitle()

        );



        poster.setScaleType(

			ImageView.ScaleType.CENTER_CROP

        );



        ImageLoader.load(

			context,

			movie.getImageUrl(),

			poster

        );





        convertView.setOnClickListener(

			new View.OnClickListener() {


				@Override

				public void onClick(View v) {


					Intent intent = new Intent(

						context,

						PlayerActivity.class

					);


					intent.putExtra(

						"videoUrl",

						movie.getVideoUrl()

					);


					context.startActivity(intent);


				}

			}

        );



        return convertView;


    }


}
