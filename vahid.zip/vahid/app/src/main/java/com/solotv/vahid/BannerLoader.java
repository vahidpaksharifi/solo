package com.solotv.vahid;


import android.os.Handler;
import android.os.Looper;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.ArrayList;



public class BannerLoader {


    public interface BannerListener {

        void onLoaded(ArrayList<Banner> banners);

    }





    public static void load(final String url, final BannerListener listener) {



        new Thread(new Runnable() {



				@Override
				public void run() {



					final ArrayList<Banner> list = new ArrayList<>();



					try {



						URL address = new URL(url);



						InputStream inputStream =
                            address.openStream();



						BufferedReader reader =
                            new BufferedReader(
							new InputStreamReader(inputStream)
						);



						StringBuilder builder =
                            new StringBuilder();



						String line;



						while((line = reader.readLine()) != null){


							builder.append(line);


						}



						reader.close();




						JSONArray array =
                            new JSONArray(builder.toString());




						for(int i = 0; i < array.length(); i++){



							JSONObject object =
                                array.getJSONObject(i);



							String image =
                                object.getString("imageUrl");



							String link =
                                object.getString("linkUrl");



							list.add(

                                new Banner(
									image,
									link
                                )

							);


						}



					}catch(Exception e){


						e.printStackTrace();


					}






					new Handler(Looper.getMainLooper()).post(new Runnable(){



							@Override
							public void run(){



								if(listener != null){


									listener.onLoaded(list);


								}



							}



						});



				}



			}).start();



    }



}
