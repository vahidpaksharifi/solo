package com.solotv.vahid;


import android.app.Activity;
import android.os.Bundle;

import android.graphics.Color;

import android.view.View;

import android.webkit.WebView;
import android.webkit.WebSettings;

import android.widget.GridView;

import java.util.ArrayList;



public class MovieListActivity extends Activity {



    GridView movieGrid;

    WebView backgroundWeb;


    ArrayList<Movie> movieList;


    MovieAdapter adapter;





    @Override
    public void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);



        getWindow().setStatusBarColor(Color.TRANSPARENT);



        getWindow().getDecorView().setSystemUiVisibility(

			View.SYSTEM_UI_FLAG_LAYOUT_STABLE |

			View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN

        );



        setContentView(R.layout.activity_movie_list);





        backgroundWeb = findViewById(R.id.backgroundWeb);



        WebSettings settings = backgroundWeb.getSettings();


        settings.setJavaScriptEnabled(true);


        settings.setDomStorageEnabled(true);



        backgroundWeb.setBackgroundColor(Color.TRANSPARENT);



        backgroundWeb.loadUrl(

			"file:///android_asset/background2.html"

        );







        movieGrid = findViewById(R.id.movieGrid);



        movieGrid.setBackgroundColor(Color.TRANSPARENT);



        movieGrid.setNumColumns(2);




        movieList = new ArrayList<>();







        new JsonLoader(

			new JsonLoader.JsonListener(){



				@Override
				public void onResult(String json){



					if(json != null && !json.equals("")){



						movieList = MovieParser.parse(json);



						// ذخیره فیلم‌های لود شده برای سرچ

						MovieCache.movieList = movieList;





						adapter = new MovieAdapter(

							MovieListActivity.this,

							movieList

						);




						movieGrid.setAdapter(adapter);



					}



				}



			}



        ).execute(



			"https://raw.githubusercontent.com/vahidpaksharifi/movies.json/main/movies.json"



        );



    }


}
