package com.solotv.vahid;


import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;



import java.util.ArrayList;



public class BannerAdapter extends BaseAdapter {


    private Context context;

    private ArrayList<Banner> bannerList;



    public BannerAdapter(Context context, ArrayList<Banner> bannerList) {


        this.context = context;

        this.bannerList = bannerList;


    }




    @Override
    public int getCount() {


        return bannerList.size();


    }




    @Override
    public Object getItem(int position) {


        return bannerList.get(position);


    }




    @Override
    public long getItemId(int position) {


        return position;


    }





    @Override
    public View getView(int position, View convertView, ViewGroup parent) {



        ImageView imageView;



        if (convertView == null) {



            imageView = new ImageView(context);



            imageView.setLayoutParams(
				new ViewGroup.LayoutParams(
					ViewGroup.LayoutParams.MATCH_PARENT,
					220
				)
            );



            imageView.setScaleType(
				ImageView.ScaleType.CENTER_CROP
            );



        } else {



            imageView = (ImageView) convertView;


        }





        final Banner banner = bannerList.get(position);




        ImageLoader.load(

			context,

			banner.getImageUrl(),

			imageView

		);


        imageView.setOnClickListener(new View.OnClickListener() {


				@Override
				public void onClick(View v) {


					Intent intent =
                        new Intent(
						Intent.ACTION_VIEW
					);


					intent.setData(
                        Uri.parse(
							banner.getLinkUrl()
                        )
					);


					context.startActivity(intent);



				}


			});





        return imageView;


    }


}
