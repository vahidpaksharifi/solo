package com.solotv.vahid;


public class Genre {


    String name;

    String imageUrl;

    String moviesUrl;



    public Genre(
        String name,
        String imageUrl,
        String moviesUrl
    ){

        this.name = name;

        this.imageUrl = imageUrl;

        this.moviesUrl = moviesUrl;

    }





    public String getName(){

        return name;

    }




    public String getImageUrl(){

        return imageUrl;

    }




    public String getMoviesUrl(){

        return moviesUrl;

    }




    // موقت برای سازگاری با کدهای قدیمی

    public String getId(){

        return "";

    }


}
