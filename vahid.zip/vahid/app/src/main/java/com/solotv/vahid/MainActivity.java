package com.solotv.vahid;


import android.app.Activity;
import android.os.Bundle;
import android.view.Window;
import android.view.View;

import android.content.Intent;

import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.RotateAnimation;

import android.widget.GridView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.ImageView;

import android.graphics.Color;

import android.webkit.WebView;
import android.webkit.WebSettings;

import java.util.ArrayList;



public class MainActivity extends Activity {


	GridView movieGrid;


	SwipeBanner bannerSwipe;


	LinearLayout bannerDots;


	ArrayList<Genre> genreList;


	GenreAdapter adapter;


	ArrayList<TextView> dots;


	WebView backgroundWeb;


	View loadingOverlay;


	TextView loadingPercent;


	boolean loadingFinished = false;


	boolean bannerLoaded = false;


	boolean moviesLoaded = false;


	int loadedImages = 0;


	int totalImages = 0;




	@Override
	public void onCreate(Bundle savedInstanceState) {


		requestWindowFeature(Window.FEATURE_NO_TITLE);


		super.onCreate(savedInstanceState);



		getWindow().setStatusBarColor(Color.TRANSPARENT);



		getWindow().getDecorView().setSystemUiVisibility(

			View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |

			View.SYSTEM_UI_FLAG_LAYOUT_STABLE

		);



		setContentView(R.layout.main);





		LinearLayout searchBar = findViewById(R.id.searchBar);



		if(searchBar != null){


			searchBar.setOnClickListener(new View.OnClickListener(){


					@Override

					public void onClick(View v){


						Intent intent = new Intent(

							MainActivity.this,

							SearchActivity.class

						);


						startActivity(intent);


					}


				});


		}





		loadingOverlay = findViewById(R.id.loadingOverlay);


		loadingPercent = findViewById(R.id.loadingPercent);



		updatePercent();



		ImageView loadingIcon = findViewById(R.id.loadingIcon);



		if(loadingIcon != null){


			RotateAnimation rotate = new RotateAnimation(

				0,

				360,

				Animation.RELATIVE_TO_SELF,

				0.5f,

				Animation.RELATIVE_TO_SELF,

				0.5f

			);



			rotate.setDuration(1000);


			rotate.setRepeatCount(Animation.INFINITE);


			rotate.setInterpolator(

				new android.view.animation.LinearInterpolator()

			);



			loadingIcon.startAnimation(rotate);


		}




		TextView logoText = findViewById(R.id.logoText);



		if(logoText != null){


			AlphaAnimation glow = new AlphaAnimation(0.4f,1.0f);


			glow.setDuration(1500);


			glow.setRepeatMode(AlphaAnimation.REVERSE);


			glow.setRepeatCount(Animation.INFINITE);


			logoText.startAnimation(glow);


		}





		backgroundWeb = findViewById(R.id.backgroundWeb);


		backgroundWeb.setBackgroundColor(Color.TRANSPARENT);



		WebSettings settings = backgroundWeb.getSettings();


		settings.setJavaScriptEnabled(true);


		settings.setDomStorageEnabled(true);



		backgroundWeb.setLayerType(

			View.LAYER_TYPE_HARDWARE,

			null

		);



		backgroundWeb.loadUrl(

			"file:///android_asset/background2.html"

		);

		movieGrid = findViewById(R.id.movieGrid);


		bannerSwipe = findViewById(R.id.bannerSwipe);


		bannerDots = findViewById(R.id.bannerDots);



		dots = new ArrayList<>();





		BannerLoader.load(

			"https://raw.githubusercontent.com/vahidpaksharifi/movies.json/main/banner.json",

			new BannerLoader.BannerListener(){


				@Override

				public void onLoaded(ArrayList<Banner> banners){


					if(banners != null && banners.size() > 0){


						bannerSwipe.setBanners(banners);



						bannerDots.removeAllViews();


						dots.clear();



						for(int i=0;i<banners.size();i++){


							TextView dot = new TextView(MainActivity.this);



							dot.setText("●");


							dot.setTextSize(16);


							dot.setPadding(8,0,8,0);


							dot.setTextColor(Color.GRAY);



							bannerDots.addView(dot);


							dots.add(dot);


						}



						bannerLoaded = true;


						updateDots();


						updatePercent();


						checkLoading();



					}


				}


			}


		);






		bannerSwipe.setOnBannerChangeListener(

			new SwipeBanner.OnBannerChangeListener(){


				@Override

				public void onChanged(int position){


					updateDots();


				}


			}

		);







		genreList = new ArrayList<>();





		new JsonLoader(

			new JsonLoader.JsonListener(){


				@Override

				public void onResult(String json){


					if(json != null){



						genreList = GenreParser.parse(json);



						// ذخیره ژانرها برای سرچ

						GenreCache.genreList = genreList;





						adapter = new GenreAdapter(

							MainActivity.this,

							genreList

						);





						movieGrid.setAdapter(adapter);





						totalImages = genreList.size();



						moviesLoaded = true;



						updatePercent();


						checkLoading();



					}


				}


			}


		).execute(

			"https://raw.githubusercontent.com/vahidpaksharifi/movies.json/main/genres.json"

		);





		// لود مخفی فیلم ها برای سرچ بدون ورود به ژانر

		new JsonLoader(

			new JsonLoader.JsonListener(){


				@Override

				public void onResult(String json){



					if(json != null && !json.equals("")){


						MovieCache.movieList = MovieParser.parse(json);



					}


				}


			}


		).execute(



			"https://raw.githubusercontent.com/vahidpaksharifi/movies.json/main/movies.json"



		);



	}





	public void imageLoaded(){


		loadedImages++;


		updatePercent();


		checkLoading();


	}





	void updatePercent(){


		int percent = 0;



		if(bannerLoaded)

			percent += 30;



		if(moviesLoaded)

			percent += 30;



		if(totalImages > 0)

			percent += (loadedImages * 40) / totalImages;



		if(percent > 100)

			percent = 100;



		if(loadingPercent != null)

			loadingPercent.setText(percent + "%");


	}






	void checkLoading(){


		if(bannerLoaded && moviesLoaded && loadedImages >= totalImages && totalImages > 0 && !loadingFinished){


			loadingFinished = true;



			if(loadingPercent != null)

				loadingPercent.setText("100%");



			new android.os.Handler().postDelayed(new Runnable(){


					@Override

					public void run(){


						finishLoading();


					}


				},500);



		}


	}






	void finishLoading(){


		if(loadingOverlay != null){


			AlphaAnimation fade = new AlphaAnimation(1.0f,0.0f);


			fade.setDuration(800);


			fade.setFillAfter(true);



			loadingOverlay.startAnimation(fade);




			new android.os.Handler().postDelayed(new Runnable(){


					@Override

					public void run(){


						loadingOverlay.setVisibility(View.GONE);


					}


				},800);



		}


	}






	void updateDots(){


		if(dots == null || bannerSwipe == null)

			return;



		for(int i=0;i<dots.size();i++){


			if(i == bannerSwipe.getCurrent())


				dots.get(i).setTextColor(Color.WHITE);


			else


				dots.get(i).setTextColor(Color.GRAY);



		}


	}


}
