package com.solotv.vahid;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.content.pm.ActivityInfo;
import android.net.Uri;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageButton;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.RelativeLayout;
import android.widget.VideoView;
import android.media.MediaPlayer;
import android.widget.Toast;


public class PlayerActivity extends Activity {


    private VideoView videoView;

    private ImageButton btnPlay, btnBack, btnForward;

    private SeekBar seekBar;

    private TextView txtCurrent, txtDuration, txtTitle;

    private RelativeLayout playerControls;


    private Handler handler = new Handler();

    private boolean userSeeking = false;



    private Runnable updateRunnable = new Runnable() {

        @Override
        public void run() {

            if(videoView != null && !userSeeking){

                int current = videoView.getCurrentPosition();

                int duration = videoView.getDuration();


                if(duration > 0){

                    seekBar.setMax(duration);

                    seekBar.setProgress(current);

                    txtCurrent.setText(time(current));

                    txtDuration.setText(time(duration));

                }

            }


            handler.postDelayed(this,300);

        }
    };




    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);


        requestWindowFeature(Window.FEATURE_NO_TITLE);


        getWindow().setFlags(
			WindowManager.LayoutParams.FLAG_FULLSCREEN,
			WindowManager.LayoutParams.FLAG_FULLSCREEN
        );


        setRequestedOrientation(
			ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        );


        setContentView(R.layout.activity_player);



        videoView = findViewById(R.id.videoView);

        btnPlay = findViewById(R.id.btnPlay);

        btnBack = findViewById(R.id.btnBack);

        btnForward = findViewById(R.id.btnForward);

        seekBar = findViewById(R.id.seekBar);

        txtCurrent = findViewById(R.id.txtCurrent);

        txtDuration = findViewById(R.id.txtDuration);

        txtTitle = findViewById(R.id.txtTitle);

        playerControls = findViewById(R.id.playerControls);





        String title = getIntent().getStringExtra("title");


        if(title != null){

            txtTitle.setText(title);

        }





        String url = getIntent().getStringExtra("videoUrl");



        if(url != null && !url.isEmpty()){

            videoView.setVideoURI(Uri.parse(url));

        }




        videoView.setOnPreparedListener(
			new MediaPlayer.OnPreparedListener(){

				@Override
				public void onPrepared(MediaPlayer mp){


					// فعال کردن صدا

					mp.setVolume(1.0f,1.0f);


					videoView.start();


					btnPlay.setImageResource(
                        android.R.drawable.ic_media_pause
					);


					seekBar.setMax(
                        videoView.getDuration()
					);


					txtDuration.setText(
                        time(videoView.getDuration())
					);


					handler.post(updateRunnable);


					hideControls();


				}

			});





        videoView.setOnErrorListener(
			new MediaPlayer.OnErrorListener(){


				@Override
				public boolean onError(
                    MediaPlayer mp,
                    int what,
                    int extra
				){

					Toast.makeText(
                        PlayerActivity.this,
                        "فرمت صدا یا ویدیو پشتیبانی نمی‌شود",
                        Toast.LENGTH_LONG
					).show();


					return false;

				}

			});






        videoView.setOnCompletionListener(
			new MediaPlayer.OnCompletionListener(){


				@Override
				public void onCompletion(MediaPlayer mp){

					btnPlay.setImageResource(
                        android.R.drawable.ic_media_play
					);

					showControls();

				}

			});






        btnPlay.setOnClickListener(
			new View.OnClickListener(){


				@Override
				public void onClick(View v){


					if(videoView.isPlaying()){


						videoView.pause();


						btnPlay.setImageResource(
                            android.R.drawable.ic_media_play
						);


						showControls();



					}else{


						videoView.start();


						btnPlay.setImageResource(
                            android.R.drawable.ic_media_pause
						);


						hideControls();


					}

				}

			});






        btnBack.setOnClickListener(
			new View.OnClickListener(){


				@Override
				public void onClick(View v){


					int pos =
                        videoView.getCurrentPosition()-10000;


					if(pos < 0)
						pos=0;


					videoView.seekTo(pos);


				}

			});






        btnForward.setOnClickListener(
			new View.OnClickListener(){


				@Override
				public void onClick(View v){


					int pos =
                        videoView.getCurrentPosition()+10000;


					if(pos > videoView.getDuration())

						pos = videoView.getDuration();



					videoView.seekTo(pos);


				}

			});






        seekBar.setOnSeekBarChangeListener(
			new SeekBar.OnSeekBarChangeListener(){


				@Override
				public void onProgressChanged(
                    SeekBar bar,
                    int progress,
                    boolean fromUser){


					if(fromUser)

						txtCurrent.setText(time(progress));


				}



				@Override
				public void onStartTrackingTouch(
                    SeekBar bar){

					userSeeking=true;

				}




				@Override
				public void onStopTrackingTouch(
                    SeekBar bar){


					videoView.seekTo(
                        bar.getProgress()
					);


					userSeeking=false;


				}

			});






        videoView.setOnClickListener(
			new View.OnClickListener(){


				@Override
				public void onClick(View v){


					if(playerControls.getVisibility()
					   == View.VISIBLE){


						hideControls();


					}else{


						showControls();


					}


				}

			});



    }






    private void hideControls(){


        handler.removeCallbacks(updateRunnable);



        playerControls.animate()
			.alpha(0)
			.setDuration(400)
			.withEndAction(
			new Runnable(){

				@Override
				public void run(){

					playerControls.setVisibility(
						View.GONE
					);

				}

			}).start();


    }







    private void showControls(){


        playerControls.setVisibility(
			View.VISIBLE
        );


        playerControls.setAlpha(1);


        handler.post(updateRunnable);


    }






    private String time(int ms){


        if(ms < 0)

            ms=0;



        int total = ms/1000;


        int hour = total/3600;


        int min = (total%3600)/60;


        int sec = total%60;




        if(hour>0)

            return String.format(
				"%02d:%02d:%02d",
				hour,min,sec
            );



        return String.format(
			"%02d:%02d",
			min,sec
        );


    }







    @Override
    protected void onPause(){

        super.onPause();


        if(videoView != null &&
		   videoView.isPlaying()){


            videoView.pause();


        }

    }






    @Override
    protected void onDestroy(){


        super.onDestroy();


        handler.removeCallbacksAndMessages(null);


        if(videoView != null){


            videoView.stopPlayback();


        }

    }


}
