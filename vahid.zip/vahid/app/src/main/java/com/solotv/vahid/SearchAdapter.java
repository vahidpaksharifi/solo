package com.solotv.vahid;


import android.content.Context;
import android.content.Intent;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;



public class SearchAdapter extends BaseAdapter {



    Context context;

    ArrayList<SearchResult> list;





    public SearchAdapter(
		Context context,
		ArrayList<SearchResult> list
    ){


        this.context = context;

        this.list = list;


    }






    @Override
    public int getCount(){


        return list.size();


    }





    @Override
    public Object getItem(int position){


        return list.get(position);


    }





    @Override
    public long getItemId(int position){


        return position;


    }






    @Override
    public View getView(
		int position,
		View convertView,
		ViewGroup parent
    ){



        if(convertView == null){


            convertView = LayoutInflater.from(context)

				.inflate(
				R.layout.movie_item,
				parent,
				false
			);


        }




        ImageView image =
			convertView.findViewById(
			R.id.moviePoster
		);



        TextView title =
			convertView.findViewById(
			R.id.movieTitle
		);





        final SearchResult item = list.get(position);




        title.setText(

			item.getTitle()

        );




        ImageLoader.load(

			context,

			item.getImageUrl(),

			image

        );





        convertView.setOnClickListener(

			new View.OnClickListener(){


				@Override
				public void onClick(View v){



					if(item.getType().equals("movie")){


						Intent intent = new Intent(

							context,

							PlayerActivity.class

						);



						intent.putExtra(

							"movieUrl",

							item.getMovie()
							.getVideoUrl()

						);



						context.startActivity(intent);


					}



				}


			}


        );




        return convertView;


    }


}
