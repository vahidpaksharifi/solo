package com.solotv.vahid;


import android.app.Activity;
import android.os.Bundle;

import android.widget.GridView;

import java.util.ArrayList;



public class GenreActivity extends Activity {



    GridView genreGrid;


    ArrayList<Genre> genreList;


    GenreAdapter adapter;





    @Override
    protected void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);


        setContentView(R.layout.activity_genre);



        genreGrid = findViewById(R.id.genreGrid);



        genreList = new ArrayList<>();




        new JsonLoader(

			new JsonLoader.JsonListener(){


				@Override
				public void onResult(String json){



					if(json != null){



						genreList = GenreParser.parse(json);



						adapter = new GenreAdapter(

							GenreActivity.this,

							genreList

						);



						genreGrid.setAdapter(adapter);



					}



				}



			}


        ).execute(


			"https://raw.githubusercontent.com/vahidpaksharifi/movies.json/main/genres.json"


        );



    }



}
