package com.solotv.vahid;


import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.widget.ImageView;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.URL;
import java.security.MessageDigest;



public class ImageLoader {



    public static void load(
        final Context context,
        final String url,
        final ImageView imageView
    ){


        new Thread(new Runnable(){


				@Override
				public void run(){


					Bitmap bitmap = null;


					try{


						File cacheFile =
							new File(
                            context.getCacheDir(),
                            md5(url) + ".png"
                        );



						if(cacheFile.exists()){


							FileInputStream input =
								new FileInputStream(cacheFile);


							bitmap =
								BitmapFactory.decodeStream(input);


							input.close();



						}else{


							InputStream inputStream =
								new URL(url).openStream();


							bitmap =
								BitmapFactory.decodeStream(inputStream);


							inputStream.close();



							if(bitmap != null){


								FileOutputStream output =
									new FileOutputStream(cacheFile);



								bitmap.compress(
									Bitmap.CompressFormat.PNG,
									100,
									output
								);


								output.flush();

								output.close();


							}


						}



						final Bitmap finalBitmap = bitmap;



						imageView.post(new Runnable(){


								@Override
								public void run(){



									if(finalBitmap != null){



										imageView.setImageBitmap(finalBitmap);



										// کمی صبر تا تصویر واقعا روی صفحه قرار بگیرد

										imageView.postDelayed(new Runnable(){


												@Override
												public void run(){



													if(context instanceof MainActivity){



														MainActivity activity =
															(MainActivity) context;



														activity.imageLoaded();



													}



												}



											},300);



									}else{



										// اگر عکس خراب بود، شمارش گیر نکند

										if(context instanceof MainActivity){


											MainActivity activity =
												(MainActivity) context;


											activity.imageLoaded();


										}



									}



								}



							});



					}catch(Exception e){



						e.printStackTrace();



						// جلوگیری از گیر کردن لودینگ در خطای دانلود

						imageView.post(new Runnable(){


								@Override
								public void run(){



									if(context instanceof MainActivity){


										MainActivity activity =
											(MainActivity) context;


										activity.imageLoaded();


									}


								}


							});



					}



				}



			}).start();



    }





    private static String md5(String text){


        try{


            MessageDigest digest =
                MessageDigest.getInstance("MD5");



            byte[] messageDigest =
                digest.digest(
				text.getBytes()
			);



            StringBuilder hexString =
                new StringBuilder();



            for(byte b : messageDigest){


                String h =
                    Integer.toHexString(
					0xFF & b
				);



                while(h.length() < 2){


                    h = "0" + h;


                }



                hexString.append(h);



            }



            return hexString.toString();



        }catch(Exception e){



            return String.valueOf(
                text.hashCode()
            );



        }



    }



}
