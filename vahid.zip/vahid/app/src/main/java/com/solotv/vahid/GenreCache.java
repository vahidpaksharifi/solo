package com.solotv.vahid;

import java.util.ArrayList;

public class GenreCache {


    public static ArrayList<Genre> genreList =
	new ArrayList<>();


}
