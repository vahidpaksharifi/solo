package com.solotv.vahid;


public class Banner {


    private String imageUrl;

    private String linkUrl;



    public Banner(String imageUrl, String linkUrl) {


        this.imageUrl = imageUrl;

        this.linkUrl = linkUrl;


    }



    public String getImageUrl() {

        return imageUrl;

    }



    public String getLinkUrl() {

        return linkUrl;

    }


}

