package com.solotv.vahid;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Path;
import android.graphics.RectF;
import android.util.AttributeSet;

import android.widget.ImageView;


public class RoundedImageView extends ImageView {


    private float radius = 25f;



    public RoundedImageView(Context context) {

        super(context);

    }


    public RoundedImageView(Context context, AttributeSet attrs) {

        super(context, attrs);

    }



    public RoundedImageView(Context context, AttributeSet attrs, int defStyle) {

        super(context, attrs, defStyle);

    }




    // حفظ نسبت پوستر 3:4
    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {


        int width = MeasureSpec.getSize(widthMeasureSpec);


        int height = width * 4 / 3;



        int newHeightSpec = MeasureSpec.makeMeasureSpec(

			height,

			MeasureSpec.EXACTLY

        );



        super.onMeasure(

			widthMeasureSpec,

			newHeightSpec

        );


    }





    @Override
    protected void onDraw(Canvas canvas) {


        Path path = new Path();


        RectF rect = new RectF(

			0,

			0,

			getWidth(),

			getHeight()

        );



        path.addRoundRect(

			rect,

			radius,

			radius,

			Path.Direction.CW

        );



        canvas.save();



        canvas.clipPath(path);



        super.onDraw(canvas);



        canvas.restore();


    }


}
