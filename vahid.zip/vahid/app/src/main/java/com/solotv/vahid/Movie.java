package com.solotv.vahid;

public class Movie {

    private String title;
    private String imageUrl;
    private String videoUrl;


    public Movie(String title, String imageUrl, String videoUrl) {

        this.title = title;
        this.imageUrl = imageUrl;
        this.videoUrl = videoUrl;

    }


    public String getTitle() {

        return title;

    }


    public String getImageUrl() {

        return imageUrl;

    }


    public String getVideoUrl() {

        return videoUrl;

    }

}
