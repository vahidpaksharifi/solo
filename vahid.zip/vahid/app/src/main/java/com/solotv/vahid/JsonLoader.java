package com.solotv.vahid;


import android.os.AsyncTask;

import java.io.BufferedReader;
import java.io.InputStreamReader;

import java.net.HttpURLConnection;
import java.net.URL;



public class JsonLoader extends AsyncTask<String, Void, String> {


    public interface JsonListener {

        void onResult(String json);

    }



    private JsonListener listener;



    public JsonLoader(JsonListener listener){

        this.listener = listener;

    }





    @Override
    protected String doInBackground(String... urls){


        try{


            URL url = new URL(urls[0]);


            HttpURLConnection connection =
                (HttpURLConnection) url.openConnection();



            connection.setRequestMethod("GET");


            // جلوگیری از استفاده از JSON قدیمی

            connection.setUseCaches(false);

            connection.setRequestProperty(
                "Cache-Control",
                "no-cache"
            );

            connection.setRequestProperty(
                "Pragma",
                "no-cache"
            );


            connection.connect();





            BufferedReader reader =
                new BufferedReader(

				new InputStreamReader(

					connection.getInputStream()

				)

			);





            StringBuilder builder =
                new StringBuilder();





            String line;



            while((line = reader.readLine()) != null){


                builder.append(line);


            }



            reader.close();



            connection.disconnect();



            return builder.toString();



        }catch(Exception e){


            return null;


        }


    }








    @Override
    protected void onPostExecute(String result){


        if(listener != null){


            listener.onResult(result);


        }


    }



}
